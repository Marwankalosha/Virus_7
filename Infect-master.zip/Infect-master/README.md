<h1 align="center">Infect v1.0</h1>
<p align="center">
     A new way to spread a fun as virus by just sending link in android.
</p>

## ?? ***About Infect***:

Infect is a bash based script which is officially made for termux users and from this tool you can spread android virus by just sending link. This tool works on both rooted Android device and Non-rooted Android device.

[![Build Status](https://img.shields.io/github/stars/noob-hackers/Infect.svg)](https://github.com/noob-hackers/Infect)
[![Build Status](https://img.shields.io/github/forks/noob-hackers/Infect.svg)](https://github.com/noob-hackers/Infect)
[![License: MIT](https://img.shields.io/github/license/noob-hackers/Infect.svg)](https://github.com/noob-hackers/Infect)
[![Rawsec's CyberSecurity Inventory](https://inventory.rawsec.ml/img/badges/Rawsec-inventoried-FF5050_flat.svg)](https://inventory.rawsec.ml/tools.html#Infect)
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Awesome](https://awesome.re/badge.svg)](https://awesome.re)

![photo_2019-06-29_15-32-01](https://user-images.githubusercontent.com/49580304/70858686-834b6580-1f2c-11ea-9ea6-0839251db161.jpg)


### ?? ***Infect is available for***:

* Termux

### ?? ***Installation and usage guide***:
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ pkg install python -y 
```
```
$ pkg install python2 -y
```
```
$ pkg install git -y
```
```
$ pip install lolcat
```
```
$ git clone https://github.com/noob-hackers/Infect
```
```
$ ls
```
```
$ cd infect
```
```
$ ls
```
```
$ bash infect.sh
```

* Now you need internet connection to continue further process...

* You can select any option by clicking on your keyboard

* Note:- Don't delete any of the scripts included in lol file

# ?? ***More***:

__Infect__ :
- From this option you will get link of virus in your termux just send that link to your victim and let the fun happen.

__Save__ :
- From this option you can repair damaged device of your victm from that virus by just installing this anti-virus in his device.

__Update__ :
- From this option you can update the infect script.

__Exit__ :
- From this option you can exit from infect tool 

## ?? ***Screenshot*** :
<img src="https://user-images.githubusercontent.com/49580304/70858686-834b6580-1f2c-11ea-9ea6-0839251db161.jpg" width="80%"></img>

## ?? ***Full video tutorial***:
[![m-wiz metasploit-franework tool](https://img.youtube.com/vi/8RXVODXMsa8/0.jpg)](https://youtu.be/8RXVODXMsa8)
## ?? ***Check this***

### Subscribe our channel on youtube:
https://www.youtube.com/noobhackers

### Chekout our webite:
https://www.noob-hackers.com

## ?? ***Join***

### Facebook group: 
https://www.facebook.com/groups/1936478173310085

### Telegram channel:
https://t.me/noobhack

### Facebook page:
https://www.facebook.com/Noob-Hackers-250938565573643

### Instagram: 
https://www.instagram.com/noobhackers352

### Pinterest:
https://in.pinterest.com/noobhackers

### My GitHub ID link:
https://www.github.com/noob-hackers

### ?? Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
