cyn='\e[0;36m'

lgrn='\e[1;32m'

r='\e[1;31m'

y='\e[1;33m'
################
clear
echo
echo
echo
echo '


                    _  _  _____  ____  ____
                   ( \( )(  _  )(_  _)( ___)
                    )  (  )(_)(   )(   )__)
                   (_)\_)(_____) (__) (____) ' | lolcat
echo " "
echo " "
cat save.txt
echo " "
echo "                      " Be polite buddy | lolcat
echo " "
echo " "
sleep 50.0
clear
cd $HOME/infect
bash infect.sh
exit
